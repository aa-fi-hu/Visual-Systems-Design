# The Ishihara Colour Test

The pictures (called plates) are shown below from 1 to 12.  Identify the number embedded within the picture and check if you managed to identify all of them correctly [here](assets/ishihara_test/answers.md).

#### Plate 1:

<p align="center"> <img src="assets/ishihara_test/Ishihara_01.jpg" /> </p><BR>

#### Plate 2:

<p align="center"> <img src="assets/ishihara_test/Ishihara_02.jpg" /> </p><BR>

#### Plate 3:

<p align="center"> <img src="assets/ishihara_test/Ishihara_03.jpg" /> </p><BR>

#### Plate 4:

<p align="center"> <img src="assets/ishihara_test/Ishihara_04.jpg" /> </p><BR>

#### Plate 5:

<p align="center"> <img src="assets/ishihara_test/Ishihara_05.jpg" /> </p><BR>

#### Plate 6:

<p align="center"> <img src="assets/ishihara_test/Ishihara_06.jpg" /> </p><BR>

#### Plate 7:

<p align="center"> <img src="assets/ishihara_test/Ishihara_07.jpg" /> </p><BR>

#### Plate 8:

<p align="center"> <img src="assets/ishihara_test/Ishihara_08.jpg" /> </p><BR>

#### Plate 9:

<p align="center"> <img src="assets/ishihara_test/Ishihara_09.jpg" /> </p><BR>

#### Plate 10:

<p align="center"> <img src="assets/ishihara_test/Ishihara_10.jpg" /> </p><BR>


#### Plate 11:

<p align="center"> <img src="assets/ishihara_test/Ishihara_11.jpg" /> </p><BR>


#### Plate 12:

<p align="center"> <img src="assets/ishihara_test/Ishihara_12.jpg" /> </p><BR>


