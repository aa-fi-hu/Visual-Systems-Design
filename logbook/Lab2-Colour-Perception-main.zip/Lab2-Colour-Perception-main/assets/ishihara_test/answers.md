# Answers to the 12 Ishihara plates

* Plate 0 - 12
* Plate 1 - 74
* Plate 2 - 6
* Plate 3 - 16
* Plate 4 - 2
* Plate 5 - 29
* Plate 6 - 7
* Plate 7 - 45
* Plate 8 - 5
* Plate 9 - 97
* Plate 10 - 8
* Plate 11 - 42
* Plate 12 - 3
